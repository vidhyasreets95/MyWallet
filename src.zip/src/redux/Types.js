export const ADD_EXPENSE = 'ADD_EXPENSE';
export const SET_BUDGET = 'SET_BUDGET';
export const SET_CREDIT = 'SET_CREDIT';